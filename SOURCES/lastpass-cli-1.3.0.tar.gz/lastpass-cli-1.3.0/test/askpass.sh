#!/bin/bash
. $(dirname $0)/include.sh

echo $TEST_PASS
