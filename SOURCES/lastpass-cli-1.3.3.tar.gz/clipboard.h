#ifndef CLIPBOARD_H
#define CLIPBOARD_H

void clipboard_open(void);
void clipboard_close(void);

#endif
